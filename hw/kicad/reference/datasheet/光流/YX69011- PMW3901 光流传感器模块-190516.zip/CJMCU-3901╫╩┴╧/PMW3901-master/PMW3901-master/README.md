# PMW3901

Simple sketch for the [PMW3901 breakout board](https://www.tindie.com/products/onehorse/pmw3901-optical-flow-sensor/) running on a Dragonfly STM32L476 development board, although any Arduino MCU with SPI can be used. Make sure to add Bitcraze's [PMW3901 library](https://github.com/bitcraze/Bitcraze_PMW3901) to your Arduino IDE.

![PMW3901board](https://user-images.githubusercontent.com/6698410/36648470-da9c7e90-1a48-11e8-8627-06c4ce7c016b.jpg)

Board available at [Tindie](https://www.tindie.com/products/onehorse/pmw3901-optical-flow-sensor/?pt=ac_prod_search).
